<?php
function hajira_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'main_menu' => __('Main Menu', 'hajira')
    ));
}
add_action('after_setup_theme', 'hajira_setup');

function hajira_enqueue_styles() {
    wp_enqueue_style('main-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'hajira_enqueue_styles');

function enqueue_carousel_scripts() {
    // Swiper CSS
    wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css', array(), null);

    // Swiper JS
    wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js', array(), null, true);

    // Custom Script
    wp_enqueue_script('custom-carousel', get_template_directory_uri() . '/js/carousel.js', array('swiper-js'), null, true);
}
add_action('wp_enqueue_scripts', 'enqueue_carousel_scripts');

add_theme_support('post-thumbnails');
add_filter('wp_get_attachment_image_attributes', function ($attr) {
    $attr['loading'] = 'lazy';
    return $attr;
});


function hajira_footer_widgets() {
    register_sidebar(array(
        'name'          => 'Footer Widget 1',
        'id'            => 'footer-1',
        'description'   => 'Add widgets here for the first column of the footer.',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
    register_sidebar(array(
        'name'          => 'Footer Widget 2',
        'id'            => 'footer-2',
        'description'   => 'Add widgets here for the second column of the footer.',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
    register_sidebar(array(
        'name'          => 'Footer Widget 3',
        'id'            => 'footer-3',
        'description'   => 'Add widgets here for the third column of the footer.',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'hajira_footer_widgets');

function register_footer_menu() {
    register_nav_menu('footer-menu', 'Footer Menu');
}
add_action('init', 'register_footer_menu');


function hajira_theme_setup() {
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'custom-header' );
    add_theme_support( 'custom-background' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'editor-style.css' );
    add_theme_support('title-tag');
}
add_action( 'after_setup_theme', 'hajira_theme_setup' );


function hajira_register_block_features() {
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'align-wide' );
    register_block_pattern_category( 'hajira-patterns', array( 'label' => __( 'Hajira Patterns', 'hajira' ) ) );
}
add_action( 'after_setup_theme', 'hajira_register_block_features' );

function hajira_register_block_styles() {
    // Add a custom style for the paragraph block
    register_block_style(
        'core/paragraph', // Target block: core/paragraph
        array(
            'name'  => 'highlighted', // Internal style name
            'label' => __( 'Highlighted Text', 'hajira' ), // Display label
            'inline_style' => 'p.is-style-highlighted { background-color: yellow; font-weight: bold; }', // Custom CSS
        )
    );

    // Add a custom style for the image block
    register_block_style(
        'core/image', // Target block: core/image
        array(
            'name'  => 'rounded', // Internal style name
            'label' => __( 'Rounded Corners', 'hajira' ), // Display label
            'inline_style' => 'img.is-style-rounded { border-radius: 15px; }', // Custom CSS
        )
    );
}
add_action( 'init', 'hajira_register_block_styles' );

function hajira_enqueue_block_styles() {
    wp_enqueue_style(
        'hajira-block-styles',
        get_template_directory_uri() . '/css/block-styles.css', // Path to your CSS file
        array(),
        '1.0'
    );
}
add_action( 'enqueue_block_editor_assets', 'hajira_enqueue_block_styles' );


function hajira_enqueue_comment_reply_script() {
    // Check if the current post has open comments and if threaded comments are enabled.
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'hajira_enqueue_comment_reply_script' );




function hajira_custom_title( $title ) {
    // Example: Add a custom suffix to the title
    if ( is_singular() ) {
        $title['title'] .= ' | Custom Suffix';
    }
    return $title;
}
add_filter( 'document_title_parts', 'hajira_custom_title' );

