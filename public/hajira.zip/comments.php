
<?php echo get_avatar( $comment, 64 ); ?>


<?php
/**
 * The template for displaying comments
 *
 * This template displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @package hajira
 */

// If the post is password protected and the visitor has not yet entered the password, return early without loading the comments.
if ( post_password_required() ) {
    return;
}
?>

<div id="comments" class="comments-area">

    <?php if ( have_comments() ) : ?>
        <h2 class="comments-title">
            <?php
            printf(
                /* translators: %1$s: comment count, %2$s: post title. */
                esc_html( _nx( 
                    '%1$s Comment on “%2$s”', 
                    '%1$s Comments on “%2$s”', 
                    get_comments_number(), 
                    'comments title', 
                    'hajira' 
                ) ),
                number_format_i18n( get_comments_number() ),
                '<span>' . get_the_title() . '</span>'
            );
            ?>
        </h2>

        <ol class="comment-list">
            <?php
            wp_list_comments( array(
                'style'      => 'ol',
                'short_ping' => true,
                'avatar_size' => 50,
            ) );
            ?>
        </ol>

        <?php the_comments_navigation(); ?>

    <?php endif; // Check for have_comments(). ?>

    <?php
    // If comments are closed and there are comments, leave a note.
    if ( ! comments_open() && get_comments_number() ) :
    ?>
        <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'hajira' ); ?></p>
    <?php endif; ?>

    <?php
    comment_form(array(
        'title_reply'          => __( 'Leave a Comment', 'hajira' ),
        'title_reply_before'   => '<h3 class="comment-reply-title">',
        'title_reply_after'    => '</h3>',
        'comment_notes_before' => '<p class="comment-notes">' . __( 'Your email address will not be published.', 'hajira' ) . '</p>',
        'class_submit'         => 'submit btn btn-primary',
        'label_submit'         => __( 'Post Comment', 'hajira' ),
    ) );
    ?>

</div><!-- #comments -->
