Theme name: Hajira
Description: This theme is build in the aim to provide the best solution for the single landing page user. 
Installation instructions: Just to install, you will need to keep in theme directory or download and install from theme area in admin section.
Licensing details: This theme is build under GNU or leter.
Changelog: install and use based on the availability of the setting of wp features.