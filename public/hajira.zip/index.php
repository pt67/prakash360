<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
    <?php get_header(); ?>


    <section class="showcase">
    <div class="carousel swiper">
        <div class="swiper-wrapper">
            <?php
            // Fetch posts dynamically
            $query = new WP_Query(array(
                'post_type' => 'post',
                'posts_per_page' => 5,
            ));

            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post();
                    if (has_post_thumbnail()) : ?>
                        <div class="swiper-slide">
                            <?php echo get_the_post_thumbnail(get_the_ID(), 'full', array('class' => 'carousel-image')); ?>
                            <div class="carousel-caption">
                                <h3><?php the_title(); ?></h3>
                                <p><?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?></p>
                                <a href="<?php the_permalink(); ?>" class="btn">Read More</a>
                            </div>
                        </div>
                    <?php endif;
                endwhile;
                wp_reset_postdata();
            else : ?>
                <p>No posts found</p>
            <?php endif; ?>
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
        <?php wp_link_pages( array(
    'before' => '<div class="page-links">' . __( 'Pages:', 'hajira' ),
    'after'  => '</div>',
) ); ?>

        <!-- Add Navigation -->
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>
</section>




    <div id="content post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <?php
        if (have_posts()) :
            while (have_posts()) : the_post();
                the_title('<h1 id="post_title">', '</h1>');
                 
                the_content('<div class="inner_content">', '</div>');
                
            endwhile;
        else :
            echo '<p>No content found</p>';
        endif;
        ?>
    </div>
    <div class="post-tags"><?php the_tags(); ?></div>
<?php the_posts_navigation(); ?>

    <?php get_footer(); ?>
    <?php wp_footer(); ?>

    
</body>
</html>
