
<header class="site-header">
    <div class="container">
        <h1 class="logo">
            <a href="<?php echo esc_url( home_url() ); ?>"><?php bloginfo('name');?></a>
        </h1>
        <nav class="main-navigation">
            <?php wp_nav_menu(array(
                'theme_location' => 'main_menu',
                'menu_class'     => 'menu',
                'container'      => false
            )); ?>
        </nav>
        <button class="menu-toggle" aria-label="Toggle menu">
            <span class="hamburger"></span>
        </button>
    </div>
</header>


